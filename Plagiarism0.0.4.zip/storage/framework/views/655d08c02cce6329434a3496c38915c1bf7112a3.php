<?php echo e($slot); ?>

<?php /**PATH E:\Laravel\Plagiarism\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>