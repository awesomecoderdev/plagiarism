<?php echo e($slot); ?>

<?php /**PATH E:\Laravel\Plagiarism\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>